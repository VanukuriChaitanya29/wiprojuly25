package com.wipro.basic;

public class Exercise_8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num = 8; // You can change this to any integer

        if (num % 2 == 0) {
            System.out.println("Number is even");
        } else {
            System.out.println("Number is odd");
        }
	}

}
