package com.wipro.basic;

import java.util.Date;

public class HelloWorld {

	public static void main(String[] args) {
		
		System.out.println("Hello World");
		
		
	}

}
