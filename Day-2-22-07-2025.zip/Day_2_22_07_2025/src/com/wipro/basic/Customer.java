package com.wipro.basic;

public class Customer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String customerName;
		String phoneNumber;
		String emaiId;
		String address;
		
		
		
	}

}
