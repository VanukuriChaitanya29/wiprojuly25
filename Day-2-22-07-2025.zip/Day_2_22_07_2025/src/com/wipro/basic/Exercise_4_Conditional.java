package com.wipro.basic;

public class Exercise_4_Conditional {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		char shape='R';
		
		if(shape=='R')	
		{
			System.out.println("Shape is Rectangle");
		}
		else if(shape=='C')
		{
			System.out.println("Sahpe is Circle");
		}
		else if(shape=='S')
		{
			System.out.println("Shape is Square");
		}
		else
		{
			System.out.println("Other");
		}
	}

}
