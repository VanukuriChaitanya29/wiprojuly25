package com.wipro.basic;

public class StringDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
