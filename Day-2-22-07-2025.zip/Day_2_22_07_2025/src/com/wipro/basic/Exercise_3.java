package com.wipro.basic;

import java.util.Date;

class Exercise_3 {

	public static void main(String[] args) {
		System.out.println("Data Entry");
		
		String Name="chaitu";
		String productNumber = "AZ-2345";
		String model="Redmi";
		String category="General";
		String subCategory="OC";
		int productLine=2;
		char productClass='B';	
		String style="Silver";
		String colour="White";
		short size=23;
		double weight=250.0d;
		float lastPrice=17.00f;
		double standardCost=100083.000d;
		Date sellStartDate=null;
		Date sellEndDate=null;
		Date discountDate=null;
		int safetyStock=1000;
		int recordPoint=750;
		short daysToMan=0;
		boolean make=true;
		boolean finishedGoods=true;
		
		
	}

}
