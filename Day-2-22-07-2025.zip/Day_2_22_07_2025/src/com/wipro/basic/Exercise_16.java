package com.wipro.basic;

public class Exercise_16 {
	public static void main(String[] args) {
		int arr[]={1,2,3,4,5};
//        for(int i=arr.length-1;i>=0;i--)
//        {
//            System.out.print(" " +arr[i]);
//
//        }
		int a[]={5,2,1,3,4};
		for (int i = arr.length - 1; i >= 0; i--) {
		    System.out.print(" " + arr[i]);
		}
	}
}
