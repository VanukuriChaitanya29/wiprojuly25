package com.wipro.basic;

import java.util.Date;

public class Exercise_2 {

	public static void main(String[] args) {
		
		System.out.println("Student Form:");
		
		String fullName="vanukuri chaitanya"; 
		int age=22;
		Date dob=null;
		char gender='f';
		long phoneNo=764372313;
		String emailId="chaitu@gmail.com";
		String eventHearing="Other";
		int numberOfTickets=66;
		
		String paymentMethod="Cash";
		
		String signature="Chaitanya";
		Date dateSigned=null;
		boolean understand=true; //false
		

	}

}
